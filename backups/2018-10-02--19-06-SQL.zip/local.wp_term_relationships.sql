/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_term_relationships` VALUES
(1,1,0),
(20,2,0),
(21,2,0),
(22,2,0),
(23,2,0),
(24,3,0),
(25,3,0),
(26,3,0),
(27,3,0),
(28,3,0),
(29,1,0),
(31,1,0);
