/*!40101 SET NAMES binary*/;
CREATE TABLE `schema_object_overview`(
`db` int,
`object_type` int,
`count` int
)ENGINE=MyISAM;
