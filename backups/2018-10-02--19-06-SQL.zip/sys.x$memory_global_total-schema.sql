/*!40101 SET NAMES binary*/;
CREATE TABLE `x$memory_global_total`(
`total_allocated` int
)ENGINE=MyISAM;
