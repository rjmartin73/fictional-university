/*!40101 SET NAMES binary*/;
CREATE TABLE `x$host_summary_by_file_io`(
`host` int,
`ios` int,
`io_latency` int
)ENGINE=MyISAM;
