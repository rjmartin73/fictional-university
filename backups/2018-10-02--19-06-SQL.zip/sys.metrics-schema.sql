/*!40101 SET NAMES binary*/;
CREATE TABLE `metrics`(
`Variable_name` int,
`Variable_value` int,
`Type` int,
`Enabled` int
)ENGINE=MyISAM;
