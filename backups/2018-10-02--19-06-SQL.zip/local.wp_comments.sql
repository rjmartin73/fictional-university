/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_comments` VALUES
(1,1,"A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2018-09-23 03:14:26","2018-09-23 03:14:26","Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.",0,"1","","",0,0),
(2,1,"Ryan","dev-email@flywheel.local","","127.0.0.1","2018-09-23 04:17:48","2018-09-23 04:17:48","This was my first post comment.",0,"1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.61","",0,1);
