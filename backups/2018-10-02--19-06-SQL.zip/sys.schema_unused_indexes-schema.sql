/*!40101 SET NAMES binary*/;
CREATE TABLE `schema_unused_indexes`(
`object_schema` int,
`object_name` int,
`index_name` int
)ENGINE=MyISAM;
