/*!40101 SET NAMES binary*/;
CREATE TABLE `memory_global_by_current_bytes`(
`event_name` int,
`current_count` int,
`current_alloc` int,
`current_avg_alloc` int,
`high_count` int,
`high_alloc` int,
`high_avg_alloc` int
)ENGINE=MyISAM;
