/*!40101 SET NAMES binary*/;
CREATE TABLE `schema_auto_increment_columns`(
`table_schema` int,
`table_name` int,
`column_name` int,
`data_type` int,
`column_type` int,
`is_signed` int,
`is_unsigned` int,
`max_value` int,
`auto_increment` int,
`auto_increment_ratio` int
)ENGINE=MyISAM;
