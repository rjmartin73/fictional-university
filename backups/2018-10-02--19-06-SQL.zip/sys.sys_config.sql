/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `sys_config` VALUES
("diagnostics.allow_i_s_tables","OFF","2018-09-10 21:57:28",NULL),
("diagnostics.include_raw","OFF","2018-09-10 21:57:28",NULL),
("ps_thread_trx_info.max_length","65535","2018-09-10 21:57:28",NULL),
("statement_performance_analyzer.limit","100","2018-09-10 21:57:28",NULL),
("statement_performance_analyzer.view",NULL,"2018-09-10 21:57:28",NULL),
("statement_truncate_len","64","2018-09-10 21:57:28",NULL);
