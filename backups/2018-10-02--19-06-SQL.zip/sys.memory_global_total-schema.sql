/*!40101 SET NAMES binary*/;
CREATE TABLE `memory_global_total`(
`total_allocated` int
)ENGINE=MyISAM;
