/*!40101 SET NAMES binary*/;
CREATE TABLE `version`(
`sys_version` int,
`mysql_version` int
)ENGINE=MyISAM;
