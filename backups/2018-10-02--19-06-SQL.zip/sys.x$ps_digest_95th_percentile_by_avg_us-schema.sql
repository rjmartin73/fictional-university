/*!40101 SET NAMES binary*/;
CREATE TABLE `x$ps_digest_95th_percentile_by_avg_us`(
`avg_us` int,
`percentile` int
)ENGINE=MyISAM;
