/*!40101 SET NAMES binary*/;
CREATE TABLE `x$wait_classes_global_by_avg_latency`(
`event_class` int,
`total` int,
`total_latency` int,
`min_latency` int,
`avg_latency` int,
`max_latency` int
)ENGINE=MyISAM;
