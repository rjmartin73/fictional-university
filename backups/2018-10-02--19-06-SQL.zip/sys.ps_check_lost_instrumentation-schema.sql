/*!40101 SET NAMES binary*/;
CREATE TABLE `ps_check_lost_instrumentation`(
`variable_name` int,
`variable_value` int
)ENGINE=MyISAM;
