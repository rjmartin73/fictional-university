/*!40101 SET NAMES binary*/;
CREATE TABLE `x$latest_file_io`(
`thread` int,
`file` int,
`latency` int,
`operation` int,
`requested` int
)ENGINE=MyISAM;
