/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_usermeta` VALUES
(1,1,"nickname","admin"),
(2,1,"first_name","Ryan"),
(3,1,"last_name","Martin"),
(4,1,"description",""),
(5,1,"rich_editing","true"),
(6,1,"syntax_highlighting","true"),
(7,1,"comment_shortcuts","false"),
(8,1,"admin_color","midnight"),
(9,1,"use_ssl","0"),
(10,1,"show_admin_bar_front","true"),
(11,1,"locale",""),
(12,1,"wp_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
(13,1,"wp_user_level","10"),
(14,1,"dismissed_wp_pointers","wp496_privacy"),
(15,1,"show_welcome_panel","1"),
(16,1,"session_tokens","a:1:{s:64:\"3a2e54e68f57a0b8c6c6473c78716d3a93af7be484deb26179e3a412f8e5d154\";a:4:{s:10:\"expiration\";i:1538619016;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:132:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.61\";s:5:\"login\";i:1538446216;}}"),
(17,1,"wp_dashboard_quick_press_last_post_id","48"),
(18,1,"community-events-location","a:1:{s:2:\"ip\";s:12:\"192.168.95.0\";}"),
(20,1,"_new_email","a:2:{s:4:\"hash\";s:32:\"4d51f817afc4081ee1e215ddba4223ed\";s:8:\"newemail\";s:22:\"rjmartin73@outlook.com\";}"),
(21,1,"managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}"),
(22,1,"metaboxhidden_nav-menus","a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}");
