/*!40101 SET NAMES binary*/;
CREATE TABLE `x$host_summary_by_stages`(
`host` int,
`event_name` int,
`total` int,
`total_latency` int,
`avg_latency` int
)ENGINE=MyISAM;
