/*!40101 SET NAMES binary*/;
CREATE TABLE `latest_file_io`(
`thread` int,
`file` int,
`latency` int,
`operation` int,
`requested` int
)ENGINE=MyISAM;
